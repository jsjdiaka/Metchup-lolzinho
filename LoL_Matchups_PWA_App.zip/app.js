
document.getElementById('app').innerText = 'Instale este app para consultar matchups de Fizz, Akali e Sylas rapidamente!';
