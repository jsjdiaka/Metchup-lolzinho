const data = [
  { campeao: "Vladimir", fizz: "Ruim", akali: "Equilibrado", sylas: "Bom", comentario: "Fizz sofre por não matar rápido. Sylas lida bem com sustain." },
  { campeao: "Sylas", fizz: "Equilibrado", akali: "Equilibrado", sylas: "Espelho", comentario: "Pequenos detalhes e experiência decidem." },
  { campeao: "Katarina", fizz: "Bom", akali: "Ruim", sylas: "Equilibrado", comentario: "Fizz é bom se cancelar ult dela. Akali sofre para reset dela." },
  { campeao: "Lux", fizz: "Ruim", akali: "Bom", sylas: "Bom", comentario: "Sylas e Akali entram fácil. Fizz depende de acertar tudo." },
  { campeao: "Ahri", fizz: "Ruim", akali: "Ruim", sylas: "Equilibrado", comentario: "Ahri consegue kitar Fizz e Akali. Sylas escala melhor." },
];

const tableBody = document.querySelector("#matchupTable tbody");
const searchInput = document.getElementById("searchInput");
const championFilter = document.getElementById("championFilter");
const statusFilter = document.getElementById("statusFilter");

function renderTable(filteredData) {
  tableBody.innerHTML = "";
  filteredData.forEach(row => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${row.campeao}</td>
      <td>${row.fizz}</td>
      <td>${row.akali}</td>
      <td>${row.sylas}</td>
      <td>${row.comentario}</td>
    `;
    tableBody.appendChild(tr);
  });
}

function filterData() {
  const search = searchInput.value.toLowerCase();
  const champ = championFilter.value;
  const status = statusFilter.value;

  const filtered = data.filter(row => {
    const matchName = row.campeao.toLowerCase().includes(search);
    const matchStatus = champ ? row[champ.toLowerCase()] === status : true;
    return matchName && matchStatus;
  });

  renderTable(filtered);
}

searchInput.addEventListener("input", filterData);
championFilter.addEventListener("change", filterData);
statusFilter.addEventListener("change", filterData);

renderTable(data);
